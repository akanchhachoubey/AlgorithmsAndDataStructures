﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SearchingAndSorting
{
    public class findMinimumSortedArray
    {
        static int[] arr;
        static int N;

        public static void execute()
        {
            arr = new int[] { 10, 12, 20, 30, 25, 40, 32, 31, 35, 50, 60 };
            N = arr.Length;
            int left = GetLeftBoundary(0, N);
            int right = GetRightBoundary(0, N);
            int left_rechecked = GetLeftBoundary(0, left);
            int right_rechecked = GetRightBoundary(right, N);
            if(left==left_rechecked )
                Console.WriteLine(left +1);
            if(right==right_rechecked  )
                Console.WriteLine(right+1);
            Console.ReadLine();
        }

        public static int GetLeftBoundary( int lower ,int higher)
        {
            if (lower < 0) return -1;
            int min = arr[lower] ;
            int i;
            for(i = lower; i<higher;i++)
            {
                if (arr[i] < min)
                    return i - 1;
                else
                {
                    min = arr[i];
                }
            }
            return i;
        }

        public static int GetRightBoundary(int lower, int higher)
        {
            if (higher > N) return N;
            int max = arr[higher-1];
            int i;
            for (i = higher-2;i>lower;i--)
            {
                if (arr[i] > max)
                    return i + 1;
                else max = arr[i];
            }
            return i;
        }
    }
}
