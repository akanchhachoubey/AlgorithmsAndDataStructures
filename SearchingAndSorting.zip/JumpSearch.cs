﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SearchingAndSorting
{
     public class JumpSearch
    {
        public static void execute()
        {
            int k = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < k; i++)
            {
                string inputs = Console.ReadLine();
                string[] vals = inputs.Split(' ');
                int len = Convert.ToInt32(vals[0]);
                int val = Convert.ToInt32(vals[1]);
                int jumplen = Convert.ToInt32(vals[2]);
                string valuesarr = Console.ReadLine();
                string[] values = valuesarr.Split(' ');
                jump(values, jumplen, val,len);
            }
            Console.ReadKey();
        }

        public static void jump(string[] arr, int jumplen, int val, int len)
        {
            int lower = 0,i=0,higher=0;
            if (val < Convert.ToInt32(arr[0]) || val > Convert.ToInt32(arr[len - 1]))
            {
                Console.WriteLine(-1);
                return;
            }
            for (i = 0; i < len; i += jumplen)
            {
                if (Convert.ToInt32(arr[i]) < val)
                {
                    lower = i;
                }
                if (Convert.ToInt32(arr[i]) > val)
                {
                    higher = i; break;
                }
            }
            if (higher == 0) higher = len - 1;
            search(arr, lower, higher, val.ToString());
            return;
        }

        public static void search(string[]arr , int lower, int higher, string value)
        {
            int i = lower;
            for ( i= lower; lower <= higher; i++)
            {
                if (arr[i] == value)
                {
                    Console.WriteLine(1);
                    break;
                }
            }
            if (i == higher)
                Console.WriteLine(-1);

        }
    }
}
