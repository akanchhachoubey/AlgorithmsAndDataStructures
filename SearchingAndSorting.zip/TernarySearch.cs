﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SearchingAndSorting
{
    public class TernarySearch
    {

        public static void execute()
        {
            int numberofcases = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < numberofcases; i++)
            {
                string NKValues = Console.ReadLine();
                string[] NKs = NKValues.Split(' ');
                int N = Convert.ToInt32(NKs[0]);
                string str = Console.ReadLine();
                string[] strs = str.Split(' ');
                Ternary(strs, 0, N - 1, NKs[1]);
            }
            Console.ReadKey();
        }

        public static void Ternary(string[] str, int lower, int higher,  string value)
        {
            if (higher > lower)
            {
                int mid1 = lower + (higher - lower) / 3;
                int mid2 = mid1 + (higher - lower) / 3;
                if (str[mid1] == value)
                    Console.WriteLine(mid1);
                if (str[mid2] == value)
                    Console.WriteLine(mid2);

                if (Convert.ToInt32(str[mid1]) > Convert.ToInt32(value))
                    Ternary(str, lower, mid1 - 1,  value);
                if (Convert.ToInt32(str[mid2]) < Convert.ToInt32(value))
                    Ternary(str, mid2 + 1, higher,  value);
                else
                    Ternary(str, mid1 + 1, mid2 - 1,  value);
            }
            if (higher == lower)
            {
                if (str[higher] == value) Console.WriteLine(higher);
                else
                    Console.WriteLine(-1);
            }
        }
    }
}
