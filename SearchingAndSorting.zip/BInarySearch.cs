﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SearchingAndSorting
{
    public class BInarySearch
    {
        static public void execute()
        {
            int numberofcases = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < numberofcases; i++)
            {
                string NKValues = Console.ReadLine();
                string[] NKs = NKValues.Split(' ');
                int N = Convert.ToInt32(NKs[0]);
                string str = Console.ReadLine();
                string[] strs = str.Split(' ');
                BinarySearch(strs, 0, N - 1, NKs[1]);
            }
            Console.ReadKey();
        }

        public static void BinarySearch(string[] arr, int lower, int higher, string value)
        {
            if (lower == higher)
            {
                if (arr[lower] == value) Console.WriteLine(lower + 1);
                else Console.WriteLine(-1);
                return;
            }

            int mid = (lower + higher) / 2;
            if (arr[mid] == value)
                Console.WriteLine(mid + 1);
            else if (Convert.ToInt32(arr[mid]) > Convert.ToInt32(value))
                BinarySearch(arr, lower, mid - 1, value);
            else
                BinarySearch(arr, mid + 1, higher, value);
        }
    }
}

