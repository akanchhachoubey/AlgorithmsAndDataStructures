﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SearchingAndSorting
{
    public class SelectionSort
    {
        static int[] arr;
        public static void execute()
        {
            arr = new int[10];
            for(int i = 0; i < 10; i++)
                arr[i] = 0;
            int j = 0;
            string str = Console.ReadLine();
            string[] strs = str.Split(' ');
            foreach (string s in strs)
            { arr[j] = Convert.ToInt32(s); j++; }
            sort(arr);
            Console.ReadLine();
        }


        public static void sort(int[] arr)
        {
            int min = 0;
            int temp = 0;
            for (int i = 0; i < 9; i++)
            {
                min = i;
                for (int j = i + 1; j < 10; j++)
                {
                    if (arr[min] > arr[j])
                        min = j;
                }
                temp = arr[i];
                arr[i] = arr[min];
                arr[min] = temp;
            }

            for (int i = 0; i < 10; i++)
                Console.Write(arr[i] + " ");
        }
    }

}
