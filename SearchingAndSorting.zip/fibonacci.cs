﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SearchingAndSorting
{
    public class fibonacci
    {
         public static int[] fib;
        public static void execute()
        {
            fib = new int[100];
            Console.WriteLine(fiboncci(40));
            Console.ReadLine();
        }
        public  static int fiboncci(int n)
        {
            if (n <= 1)
                fib[n] = n;
            else
            {
                fib[n] = fiboncci(n - 1) + fiboncci(n - 2);
                
            }
            return fib[n];
        }


    }
}
