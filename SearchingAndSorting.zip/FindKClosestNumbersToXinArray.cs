﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SearchingAndSorting
{
    public class FindKClosestNumbersToXinArray
    {
        static int[] arr;
        static int N;
        static int X;

        public static void execute()
        {
            arr = new int[] { 10, 12, 20, 30, 25, 40, 32, 31, 35, 50, 60 };
            N = arr.Length;
            X = 29;
            int Cp = CrossOver(0, N - 1);
            int k = 4;
            PrintKClosest(k,Cp);
            Console.ReadLine();
        }

        public static int CrossOver(int lower, int higher)
        {
            if (lower < higher)
            {
                int mid = (lower + higher) / 2;
                if (arr[mid] == X)
                    return mid;
                else if (arr[mid - 1] < X && X < arr[mid + 1])
                    return mid;
                else if (arr[mid] < X)
                    CrossOver(mid + 1, higher);
                else
                    CrossOver(lower, mid - 1);
            }
            else if (arr[lower] > X)
                return lower;
            return higher;
        }

        public static void PrintKClosest(int K, int Cp)
        {
            int count = 0;
            int l = 0;
            int r = 0;
            if (arr[Cp] != X)
            {
                l = Cp - 1;
                r = Cp + 1;
            }
            else
            {
                l = Cp;
                r = Cp + 1;
            }
            while (l >= 0 && r < N && count < K)
            {
                if (X - arr[l] < arr[r] - X)
                    Console.WriteLine(arr[l--]);
                else if (X - arr[l] > arr[r] - X)
                    Console.WriteLine(arr[r++]);
                else if(X - arr[l] == arr[r] - X)
                {
                    Console.WriteLine(arr[l--]);
                    count++;
                    if (count<4)
                        Console.WriteLine(arr[r++]);                    
                }
                count++;
            }
        }
    }
}
