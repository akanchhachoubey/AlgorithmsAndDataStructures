﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SearchingAndSorting
{
    public class SortAnArrayInWaveForm
    {
        static int[] arr;
        static int N;
        public static void execute()
        {
            arr = new int[] { 7, 6, 2, 1, 4, -1, 0 };
            N = arr.Length;
            SortInWave();
            for (int k = 0; k < N; k++)
                Console.Write(arr[k] + " ");
            Console.ReadLine();
        }
        public static void SortInWave()
        {
            for (int i = 0; i < N; i += 2)
            {
                if (i > 0 && arr[i - 1] > arr[i])
                    Swap(i, i - 1);
                if (i < N-1 && arr[i] < arr[i + 1])
                    Swap(i, i + 1);
            }
        }

        public static void Swap(int id1, int id2)
        {
            int temp = arr[id1];
            arr[id1] = arr[id2];
            arr[id2] = temp;
        }
    }
}
