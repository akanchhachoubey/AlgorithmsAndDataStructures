﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SearchingAndSorting
{
    public class LinearSearch
    {
        public void execute()
        {
            int numberofcases = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < numberofcases; i++)
            {
                string NKValues = Console.ReadLine();
                string[] NKs = NKValues.Split(' ');
                int N = Convert.ToInt32(NKs[0]);
                string str = Console.ReadLine();
                string[] strs = str.Split(' ');
                int j = 0;
                for (j = 0; j < N; j++)
                {
                    if (strs[j] == NKs[1])
                    {
                        Console.WriteLine(j + 1);
                        break;
                    }
                }
                if (j == N) Console.WriteLine(-1);
            }
            Console.ReadKey();
        }
    }
}
