﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SearchingAndSorting
{
    public class HeapSort
    {
        static int[] arr;
        static int N;
        public static void execute()
        {
            arr= new int[]{7,6,2,1,4,-1,0 };
            N = arr.Length;
            heap(N);
        }

        public static void heap(int n)
        {
            for (int i = n / 2 + 1; i >= 0; i--)
            {
                heapify(i,N);
            }
            
            for (int j = N - 1; j >= 0; j--)
            {
                Swap(0, j);
                heapify(0,j);
            }

        for(int k=0;k<n;k++)
                Console.Write(arr[k] +" " );
            Console.ReadLine();
        }

        public static void heapify(int i, int n)
        {
            int left = 2 * i + 1;
            int right = 2 * i + 2;
            int max = i;
            if (left < n && left >0  && arr[max] < arr[left] )
                max = left;
            if (right < n && right>0 &&  arr[max] < arr[right] )
                max = right;
            if (max != i)
            {
                Swap(i, max);
                heapify(max,n);
            }
        }

        public static void Swap(int id1, int id2)
        {
            int temp = arr[id1];
            arr[id1] = arr[id2];
            arr[id2] = temp;
        }
    }
}
