﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SearchingAndSorting
{
    public class InsertionSort
    {
        static int[] arr;
        public static void execute()
        {
            arr = new int[10];
            for (int i = 0; i < 10; i++)
                arr[i] = 0;
            int j = 0;
            string str = Console.ReadLine();
            string[] strs = str.Split(' ');
            foreach (string s in strs)
            { arr[j] = Convert.ToInt32(s); j++; }
            sort(arr);
            Console.ReadLine();
        }


        public static void sort(int[] arr)
        {
            int temp = 0;
            for (int i = 1; i < 10; i++)
            {
                temp = arr[i];
                int j = i - 1;
                while (j >= 0 && arr[j]> temp)
                {
                    arr[i] = arr[j];
                    j--;
                }
				arr[j+1] = temp;
            }

            for (int i = 0; i < 10; i++)
                Console.Write(arr[i] + " ");
        }
    }
}
