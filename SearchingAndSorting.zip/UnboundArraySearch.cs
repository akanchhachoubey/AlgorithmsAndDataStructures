﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SearchingAndSorting
{
    public class UnboundArraySearch
    {
        public static void execute()
        {
            int numberofcases = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < numberofcases; i++)
            {
                string NKValues = Console.ReadLine();
                string[] NKs = NKValues.Split(' ');
                int N = Convert.ToInt32(NKs[0]);
                string str = Console.ReadLine();
                string[] strs = str.Split(' ');
                Unbound(strs, N - 1,1,1);
            }
            Console.ReadKey();
        }

        public static int Fun(int x)
        {
            int y = Convert.ToInt32(Math.Pow(Convert.ToDouble(x), 2.0)) - 5 * x - 1;
            return y;
        }

        public static void Unbound(string[] str,int len, int current, int lower)
        {
            if (Fun(0) > 0)
                Console.WriteLine(0);
            else
            if (current > len)
                Console.WriteLine(-1);
            else
            {
                int result = Fun(Convert.ToInt32(str[current]));
                if (result > 0)
                {
                    Console.WriteLine(binarySearch(lower, current));
                }
                else
                {
                    lower = current;
                    current = current * 2;
                    Unbound(str, len, current, lower);
                }
            }
        }
        public static int binarySearch(int low, int high)
        {
            if (high >= low)
            {
                int mid = low + (high - low) / 2; 

                if (Fun(mid) > 0 && (mid == low || Fun(mid - 1) <= 0))
                    return mid;

                if (Fun(mid) <= 0)
                    return binarySearch((mid + 1), high);
                else  
                    return binarySearch(low, (mid - 1));
            }

            return -1;
        }

    }
}
