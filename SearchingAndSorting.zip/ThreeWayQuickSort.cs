﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SearchingAndSorting
{
    public class ThreeWayQuickSort
    {
        static int[] arr;
        static int N;
        public static void execute()
        {
            arr = new int[] { 4, 2, 2, 1, 4, 4, 0 };
            N = arr.Length;
            quicksort(0, N - 1);
            for (int k = 0; k < N; k++)
                Console.Write(arr[k] + " ");
            Console.ReadLine();
        }

        public static void quicksort(int lower, int higher)
        {
            int pivotstart;
            int pivotend;
            if (lower < higher)
            {
                int i = Partition(lower, higher, out pivotstart, out pivotend);
                if (pivotstart - 1 > lower)
                    quicksort(lower, pivotstart - 1);
                if (pivotend + 1 < higher)
                    quicksort(pivotend + 1, higher);
            }
        }

        public static int Partition(int lower, int higher, out int start, out int end)
        {
            int key = arr[lower];
            int i = lower;
            int count = 1;
            for (int j = lower + 1; j <= higher; j++)
            {
                if (arr[j] <= key)
                {
                    i++;
                    if (arr[j] == key)
                        count++;
                    Swap(j, i);
                }
            }
            Swap(lower, i);
            start = i - count +1;
            end = i;
            return i;
        }

        public static void Swap(int id1, int id2)
        {
            int temp = arr[id1];
            arr[id1] = arr[id2];
            arr[id2] = temp;
        }
    }
}
