﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SearchingAndSorting
{
    public class FindClosestPairToXFromTwoSortedArrays
    {
        static int[] arr;
        static int N;
        static int[] arr2;
        static int M;

        public static void execute()
        {
            arr = new int[] { 1, 4, 5, 7 };
            N = arr.Length;
            arr2 = new int[]{ 10, 20, 30, 40 };
            M = arr2.Length;
            int X = 38;
            FindPair(X);
            Console.ReadLine();
        }

        public static void FindPair(int X)
        {
            int l = 0;
            int h = M-1;
            int id1 = l;
            int id2 = h;

            int diff = int.MaxValue;

            while (l <= N - 1 && h >= 0)
            {
                if(Math.Abs(arr[l]+arr2[h]-X)<diff)
                {
                    diff = Math.Abs(arr[l] + arr2[h] - X);
                    id1 = l;
                    id2 = h;
                }
                if (arr[l] + arr2[h] > X)
                    h--;
                else if (arr[l] + arr2[h] < X)
                    l++;
            }
            Console.WriteLine(arr[id1]);
            Console.WriteLine(arr2[id2]);
        }
    }
}
