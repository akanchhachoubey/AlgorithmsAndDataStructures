﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SearchingAndSorting
{
    public class MergeSort
    {
        static int[] arr;
        public static void execute()
        {
            arr = new int[10];
            for (int i = 0; i < 10; i++)
                arr[i] = 0;
            int j = 0;
            string str = Console.ReadLine();
            string[] strs = str.Split(' ');
            foreach (string s in strs)
            { arr[j] = Convert.ToInt32(s); j++; }
            sort(arr, 0,9);

            for (int i = 0; i < 10; i++)
                Console.Write(arr[i] + " ");
            Console.ReadLine();
        }

        public static void sort(int[] arr, int lower, int higher)
        {
            if (lower < higher)
            {
                int mid = lower + (higher -lower ) / 2;
                sort(arr, lower, mid);
                sort(arr, mid + 1, higher);
                Merge_Sort(arr, lower, mid, higher);
            }

        }

        public static void Merge_Sort(int[] arr, int lower, int mid, int higher)
        {
            int N1 = mid - lower +1 ;
            int[] arr1 = new int[N1];
            int N2 = higher - mid;
            int[] arr2 = new int[N2];

            for (int i = 0; i < N1; i++)
                arr1[i] = arr[i + lower];

            for (int i = 0; i < N2; i++)
                arr2[i] = arr[i + mid+1];

            int k = 0,j=0, l=lower;
            while(k<N1 && j<N2)
            {
                if (arr1[k] > arr2[j])
                {
                    arr[l] = arr2[j];
                    j++;
                    l++;
                }
                else 
                {
                    arr[l] = arr1[k];
                    k++;
                    l++;
                }
            }
            while(k<N1)
            {
                arr[l] = arr1[k];
                l++;k++;
            }
            while (j < N2)
            {
                arr[l] = arr2[j];
                l++; j++;
            }
        }
    }
}
