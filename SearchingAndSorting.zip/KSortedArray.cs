﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SearchingAndSorting
{
    public class KSortedArray
    {
        static int[] arr;
        static int N;
        public static void execute()
        {
            arr = new int[] { 6, 5, 3, 2, 8, 10, 9 };
            N = arr.Length;
            Ksort();
            for (int k = 0; k < N; k++)
                Console.Write(arr[k] + " ");
            Console.ReadLine();
        }

        public static void Ksort()
        {
            int key,j;
            for (int i=1;i<N;i++)
            {
                key = arr[i];
                j = i - 1;
                while(j>=0 && arr[j] > key)
                {
                    arr[j + 1] = arr[j];
                    j--;
                }
                arr[j + 1] = key;
            }
        }
    }
}
