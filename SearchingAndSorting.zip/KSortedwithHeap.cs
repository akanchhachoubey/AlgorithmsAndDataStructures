﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SearchingAndSorting
{
    public class KSortedwithHeap
    {
        static int[] arr;
        static int N;
        public static void execute()
        {
            arr = new int[] { 6, 5, 3, 2, 8, 10, 9 };
            int k = 4;
            N = arr.Length;

            for (int l = 0; l < N ; l++)
            {
                heap(l, l + (k));
                if (l >= N - k)
                    k--;
            }
            //for (int l = N - k; l < N; l++)
            //{
            //    heap(l, N);
            //}

            for (k = 0; k < N; k++)
                Console.Write(arr[k] + " ");
            Console.ReadLine();
        }
        public static void heap(int lower, int higher)
        {
            int n = (higher - lower);
            for (int i = (n) / 2 + 1; i >= 0; i--)
            {
                heapify(i, higher,lower);
            }
        }

        public static void heapify(int i, int higher, int lower)
        {
            int left = lower + i * 2 + 1;
            int right = lower + 2 * i + 2;
            int min = lower + i;
            if (left < higher && arr[left] < arr[min] )
                min = left;
            if (right < higher && arr[right] < arr[min] )
                min = right;

            if (lower + i != min)
            {
                Swap(lower + i, min);
                heapify(min, higher,lower);
            }
        }

        public static void Swap(int id1, int id2)
        {
            int temp = arr[id1];
            arr[id1] = arr[id2];
            arr[id2] = temp;
        }
    }
}
