﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SearchingAndSorting
{
    public class IterativeQuickSort
    {
        static int[] arr;
        static int N;

        public static void execute()
        {
            arr = new int[] { 10, 12, 20, 30, 25, 40, 32, 31, 35, 50, 60 };
            N = arr.Length;
            quick(0, N-1);
            for(int i= 0;i<N; i++)
                Console.Write(arr[i] +" ");
            Console.ReadLine();
        }

        public static int partition(int lower, int higher)
        {
            int key = arr[lower];
            int i = lower;
            for(int j=lower+1;j<=higher;j++)
            {
                if (arr[j] <= key)
                {
                    i++;
                    Swap(i, j);
                }
            }
            Swap(i, lower);
            return i;
        }
        public static void Swap(int id1, int id2)
        {
            int temp = arr[id1];
            arr[id1] = arr[id2];
            arr[id2] = temp;
        }

        public static void quick(int l,int h)
        {
            int[] stack = new int[h - 1 + 1];
            stack[0] = l;
            stack[1] = h;
            int top = 1;

            while (top >=0)
            {
                h = stack[top--];
                l = stack[top--];

                int i = partition(l, h);
                if (l < i - 1)
                {
                    stack[++top] = l;
                    stack[++top] = i - 1;
                }
                if(h>i+1)
                {
                    stack[++top] = i + 1;
                    stack[++top] = h;
                }
            }


        }
    }
}
