﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SearchingAndSorting
{
    public class EXponentialSearch
    {
        public static void execute()
        {
            int numberofcases = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < numberofcases; i++)
            {
                string NKValues = Console.ReadLine();
                string[] NKs = NKValues.Split(' ');
                int N = Convert.ToInt32(NKs[0]);
                string str = Console.ReadLine();
                string[] strs = str.Split(' ');
                ExponentialSearch(strs, N - 1, Convert.ToInt32( NKs[1]));
            }
            Console.ReadKey();
        }
        public static void ExponentialSearch(string[] str, int len, int value)
        {
            int lower = 1;
            int higher = 2;

            if (str[0] == value.ToString())
                Console.WriteLine(0); ;
            while (higher < len)
            {
                if (Convert.ToInt32(str[higher]) < value)
                {
                    lower = higher;
                    higher = lower * 2;
                }
            }
            if (higher > len)
            {
                BInarySearch.BinarySearch(str, lower, len-1, value.ToString());
            }
            else
                BInarySearch.BinarySearch(str, lower, higher, value.ToString());
        }
    }
}
