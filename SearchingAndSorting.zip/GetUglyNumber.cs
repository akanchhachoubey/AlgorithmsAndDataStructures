﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SearchingAndSorting
{
    public class GetUglyNumber
    {
        static int[] arr { get; set; }

        public static  void execute()
        {
            arr = new int[150];
            CalculateUgly();
        }
        public static void CalculateUgly()
        {
            int i2 =0 ,i3 =0 , i5 = 0;
            arr[0] = 1;

            int nextugly = 0;
            int A = arr[i2] * 2;
            int B = arr[i3] * 3;
            int C = arr[i5] * 5;
            for (int i = 1; i < 150; i++)
            {
                nextugly = Math.Min(A,Math.Min(B,C));
                arr[i] = nextugly;
                if (nextugly == A)
                {
                    i2 = i2 + 1;
                    A = arr[i2] * 2;
                }
                if (nextugly == B)
                {
                    i3 = i3 + 1;
                    B = arr[i3] * 3;
                }
                if (nextugly == C)
                {
                    i5 = i5 + 1;
                    C = arr[i5] * 5;
                }
            }
            Console.WriteLine(arr[149]);
            Console.ReadLine();
        }
        public static int Min(int a, int b, int c, out int _match)
        {
            int A = a * 2;
            int B = b * 3;
            int C = c * 5;

            if (A < B && A < C)
            {
                _match = 1;
                return A;
            }
            else if (B < A && B < C)
            {
                _match = 2;
                return B;
            }
            else if (C < A && C < B)
            {
                _match = 3;
                return C;
            }
            else if(A==B)
            {
                _match = 4;
                return A;
            }
            else if (A == C)
            {
                _match = 5;
                return A;
            }
            else 
            {
                _match = 6;
                return A;
            }
        }
    }
}
