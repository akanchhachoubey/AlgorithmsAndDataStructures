﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SearchingAndSorting
{
    public class INterpolationSearch
    {
        public static void execute()
        {
            int numberofcases = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < numberofcases; i++)
            {
                string NKValues = Console.ReadLine();
                string[] NKs = NKValues.Split(' ');
                int N = Convert.ToInt32(NKs[0]);
                string str = Console.ReadLine();
                string[] strs = str.Split(' ');
                Interpolation(strs, 0, N - 1, NKs[1]);
            }
            Console.ReadKey();
        }

        public static void Interpolation(string[] strs, int lower, int higher, string value)
        {
            int pos = 0;
            while (higher >= lower
                && Convert.ToInt32(value) > Convert.ToInt32(strs[lower])
                && Convert.ToInt32(value) < Convert.ToInt32(strs[higher]))
            {
                pos = lower + ((higher - lower) / (Convert.ToInt32(strs[higher]) - Convert.ToInt32(strs[lower]))) * (Convert.ToInt32(value) - Convert.ToInt32(strs[lower]));
                if (strs[pos] == value)
                {
                    Console.WriteLine(pos + 1);
                    break;
                }
                if (Convert.ToInt32(strs[pos]) > Convert.ToInt32(value))
                {
                    higher = pos - 1;
                }
                else if(Convert.ToInt32(strs[pos]) < Convert.ToInt32(value))
                {
                    lower = pos + 1;
                }

            }
        }
    }
}
