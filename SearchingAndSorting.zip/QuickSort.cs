﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SearchingAndSorting
{
    public class QuickSort
    {
        static int[] arr;
        static int N;
        public static void execute()
        {
            arr = new int[] { 7, 6, 2, 1, 4, -1, 0 };
            N = arr.Length;
            quicksort(0,N-1);
            for (int k = 0; k <N; k++)
                Console.Write(arr[k] + " ");
            Console.ReadLine();
        }

        public static void quicksort(int lower, int higher)
        {
            if (lower < higher)
            {
                int i = Partition(lower, higher);
                if(i-1>lower)
                    quicksort(lower, i - 1);
                if(i+1<higher)
                    quicksort(i + 1, higher);
            }
        }

        public static int Partition(int lower, int higher)
        {
            int key = arr[lower];
            int i = lower;
            for (int j = lower + 1; j <= higher; j++)
            {
                if (arr[j] < key)
                {
                    i++;
                    Swap(j, i);
                }
            }
            Swap(lower, i);
            return i;
        }

        public static void Swap(int id1, int id2)
        {
            int temp = arr[id1];
            arr[id1] = arr[id2];
            arr[id2] = temp;
        }
    }
}
