﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SearchingAndSorting
{
    public class FindPairClosestToXinGivenSortedArray
    {
        static int[] arr;
        static int N;

        public static void execute()
        {
            arr = new int[] { 1, 4, 5, 7 };
            N = arr.Length;
            int X = 4;
            FindPair(X, 0, N - 1);
            Console.ReadLine();
        }

        public static void FindPair(int X, int lower, int higher)
        {
            int l = lower;
            int h = higher;
            int id1 = l;
            int id2 = h;
            int diff = int.MaxValue;

            while (l>=0 && h<=N-1 && h>=l)
            {
                if (Math.Abs(arr[l] + arr[h] - X) < diff)
                {
                    diff = arr[l] + arr[h] - X;
                    id1 = l;
                    id2 = h;
                }
                if ((arr[l] + arr[h]) < X)
                    l++;
                if ((arr[l] + arr[h]) > X)
                    h--;

            }
            Console.WriteLine(id1);
            Console.WriteLine(id2);
        }
    }
}
