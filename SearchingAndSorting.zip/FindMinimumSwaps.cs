﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SearchingAndSorting
{
    public class FindMinimumSwaps
    {
        static int[] arr;
        static int N;

        public static void execute()
        {
            arr = new int[] { 1, 4, 5, 7 };
            N = arr.Length;
            FindSwaps();
            Console.ReadLine();
        }

        public static void FindSwaps()
        {
            if (N > 0)
            {
                int min = arr[0];
                int max = arr[0];
                int id1 =0, id2=0;
                for (int i=0;i<N;i++)
                {
                    if (arr[i] > max)
                    { max = arr[i]; id1 = i; }
                    if (arr[i] < min)
                    { min = arr[i]; id2 = i; }
                }
                for(int i=0;i<N;i++)
                {
                    if (arr[i] == min)
                    {
                        if (i > id1)
                            id1 = i;
                        if (i < id2)
                            id2 = i;
                    }
                }
                if(id1<id2)
                    Console.WriteLine(id1+N-id2-1);
                else
                    Console.WriteLine(id1+N-id2-2);
            }
        }
    }
}
